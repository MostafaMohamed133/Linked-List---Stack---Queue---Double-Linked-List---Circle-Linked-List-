#include <iostream>
#include "StackType.h"
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {

}


