#include "SortedType.h"

SortedType::SortedType() {
    length = 0;
}

bool SortedType::IsFull() const {
    return (length == MAX_ITEMS);
}

int SortedType::LengthIs() const {
    return length;
}

void SortedType::RetrieveItem(ItemType& item, bool& found) {
    int first = 0;
    int last = length - 1;
    bool moreToSearch = first <= last;
    found = false;
    while (moreToSearch && !found) {
        int midPoint = (first + last) / 2;
        switch (item.ComparedTo(info[midPoint])) {
            case LESS: last = midPoint - 1; moreToSearch = first <= last; break;
            case GREATER: first = midPoint + 1; moreToSearch = first <= last; break;
            case EQUAL: found = true; item = info[midPoint]; break;
        }
    }
}

void SortedType::InsertItem(ItemType item) {
    int location = 0;
    bool moreToSearch = (location < length);
    while (moreToSearch) {
        switch (item.ComparedTo(info[location])) {
            case LESS: moreToSearch = false; break;
            case GREATER: location++; moreToSearch = (location < length); break;
        }
    }
    for (int i = length; i > location; i--)
        info[i] = info[i - 1];
    info[location] = item;
    length++;
}

void SortedType::DeleteItem(ItemType item) {
    int location = 0;
    while (item.ComparedTo(info[location]) != EQUAL)
        location++;
    for (int i = location + 1; i < length; i++)
        info[i - 1] = info[i];
    length--;
}

void SortedType::ResetList() {
    currentPos = -1;
}

void SortedType::GetNextItem(ItemType& item) {
    currentPos++;
    item = info[currentPos];
}

void SortedType::MergeLists(SortedType& list, SortedType& result) {
    int i = 0, j = 0;
    while (i < this->LengthIs() && j < list.LengthIs()) {
        if (this->info[i].ComparedTo(list.info[j]) == LESS) {
            result.InsertItem(this->info[i]);
            i++;
        } else {
            result.InsertItem(list.info[j]);
            j++;
        }
    }

    while (i < this->LengthIs()) {
        result.InsertItem(this->info[i]);
        i++;
    }

    while (j < list.LengthIs()) {
        result.InsertItem(list.info[j]);
        j++;
    }
}

void SortedType::SplitLists(SortedType& list1, SortedType& list2, ItemType item) {
    int i = 0;
    while (i < this->LengthIs() && this->info[i].ComparedTo(item) <= 0) {
        list1.InsertItem(this->info[i]);
        i++;
    }
    while (i < this->LengthIs()) {
        list2.InsertItem(this->info[i]);
        i++;
    }
}
