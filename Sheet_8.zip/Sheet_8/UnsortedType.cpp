#include "UnsortedType.h"

UnsortedType::UnsortedType() {
    length = 0;
}

bool UnsortedType::IsFull() const {
    return (length == MAX_ITEMS);
}

int UnsortedType::LengthIs() const {
    return length;
}

void UnsortedType::RetrieveItem(ItemType& item, bool& found) {
    int location = 0;
    found = false;
    while (location < length && !found) {
        if (item.ComparedTo(info[location]) == EQUAL) {
            found = true;
            item = info[location];
        }
        location++;
    }
}

void UnsortedType::InsertItem(ItemType item) {
    info[length] = item;
    length++;
}

void UnsortedType::DeleteItem(ItemType item) {
    int location = 0;
    while (item.ComparedTo(info[location]) != EQUAL)
        location++;
    for (int i = location + 1; i < length; i++)
        info[i - 1] = info[i];
    length--;
}

void UnsortedType::ResetList() {
    currentPos = -1;
}

void UnsortedType::GetNextItem(ItemType& item) {
    currentPos++;
    item = info[currentPos];
}

void UnsortedType::MergeLists(UnsortedType& list, UnsortedType& result) {
    for (int i = 0; i < this->LengthIs(); i++) {
        result.InsertItem(info[i]);
    }
    for (int i = 0; i < list.LengthIs(); i++) {
        result.InsertItem(list.info[i]);
    }
}

void UnsortedType::SplitLists(UnsortedType& list1, UnsortedType& list2, ItemType item) {
    for (int i = 0; i < this->LengthIs(); i++) {
        if (info[i].ComparedTo(item) <= 0) {
            list1.InsertItem(info[i]);
        } else {
            list2.InsertItem(info[i]);
        }
    }
}
