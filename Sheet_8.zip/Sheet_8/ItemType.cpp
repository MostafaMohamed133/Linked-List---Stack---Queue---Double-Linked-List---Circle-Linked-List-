#include <fstream>
#include "ItemType.h"

ItemType::ItemType() {
    value = 0;
}

ItemType::ItemType(int number) {   // New constructor to initialize value with an integer
    value = number;
}

RelationType ItemType::ComparedTo(ItemType otherItem) const {
    if (value < otherItem.value)
        return LESS;
    else if (value > otherItem.value)
        return GREATER;
    else return EQUAL;
}

void ItemType::Initialize(int number) {
    value = number;
}

void ItemType::Print(std::ofstream& out) const {
    out << value << " ";
}
