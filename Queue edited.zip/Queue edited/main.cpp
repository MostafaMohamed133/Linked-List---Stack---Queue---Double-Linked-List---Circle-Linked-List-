#include <iostream>
#include "QueType.h"
using namespace std;

int main() {

    QueType queue (5);
    for(int i=1;i<=6;i++){
    if(!queue.IsFull())
    {
        queue.Enqueue(ItemType(i*10));
        cout<<"Enqueued: "<<i*10<<endl;
    }
    else{
        cout<<"the queue is full can't add "<<i*10<<endl;
    }
    }
    ItemType item;
    while(!queue.IsEmpty())
    {
        queue.Dequeue(item);
        cout<<"Dequeued: "<<item.GetValue()<<endl;
    }
    return 0;
}
