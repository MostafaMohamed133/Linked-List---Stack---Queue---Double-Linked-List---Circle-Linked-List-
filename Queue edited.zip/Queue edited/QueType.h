#ifndef QUETYPE_H
#define QUETYPE_H

#include "ItemType.h"

class FullQueue {};
class EmptyQueue {};

class QueType {
public:
    QueType(int max);
    QueType();
    ~QueType();

    void MakeEmpty();
    bool IsEmpty() const;
    bool IsFull() const;
    void Enqueue(ItemType item);
    void Dequeue(ItemType& item);
    bool Identical(QueType queue1) const;

    ItemType Front() const;
private:
    int front;
    int rear;
    ItemType* items;
    int maxQue;
};

#endif
