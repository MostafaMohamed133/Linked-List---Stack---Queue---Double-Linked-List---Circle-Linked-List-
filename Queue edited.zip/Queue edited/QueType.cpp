#include "QueType.h"

// Constructor with parameter: initializes a queue of given maximum size
QueType::QueType(int max) {
    // +1 is used to differentiate between full and empty states in circular array
    maxQue = max + 1;
    front = maxQue - 1; // front points to the position before the first item
    rear = maxQue - 1;  // rear points to the last item in the queue
    items = new ItemType[maxQue]; // dynamically allocate the array
}

// Default constructor: creates a queue with size 500
QueType::QueType() {
    maxQue = 501;
    front = maxQue - 1;
    rear = maxQue - 1;
    items = new ItemType[maxQue];
}

// Destructor: releases the dynamically allocated array memory
QueType::~QueType() {
    delete[] items;
}

// Resets the queue to an empty state
void QueType::MakeEmpty() {
    front = maxQue - 1;
    rear = maxQue - 1;
}

// Checks whether the queue is empty
bool QueType::IsEmpty() const {
    return (rear == front);
}

// Checks whether the queue is full
bool QueType::IsFull() const {
    // The queue is full if moving rear forward wraps it to front
    return ((rear + 1) % maxQue == front);
}

// Adds an item to the rear of the queue
void QueType::Enqueue(ItemType newItem) {
    if (IsFull()) {
        // Throw exception if the queue is already full
        throw FullQueue();
    } else {
        // Move rear forward circularly and insert the item
        rear = (rear + 1) % maxQue;
        items[rear] = newItem;
    }
}

// Removes an item from the front of the queue
void QueType::Dequeue(ItemType& item) {
    if (IsEmpty()) {
        // Throw exception if the queue is empty
        throw EmptyQueue();
    } else {
        // Move front forward circularly and get the item
        front = (front + 1) % maxQue;
        item = items[front];
    }
}



