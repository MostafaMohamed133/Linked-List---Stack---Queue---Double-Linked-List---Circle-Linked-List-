#ifndef ITEMTYPE_H
#define ITEMTYPE_H

#include <iostream>

class ItemType {
public:
    ItemType() : value(0) {}
    ItemType(int number) : value(number) {}
    void Initialize(int number) { value = number; }
    int GetValue() const { return value; }

    friend std::ostream& operator<<(std::ostream& os, const ItemType& item) {
        os << item.value;
        return os;
    }

private:
    int value;
};

#endif
